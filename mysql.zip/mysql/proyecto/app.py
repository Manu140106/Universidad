import os
import mysql.connector
import time

def connect():
    while True:
        connection = None
        try:
            connection = mysql.connector.connect(
                host=os.getenv("DB_HOST", "db"),
                user=os.getenv("DB_USER", "root"),
                password=os.getenv("DB_PASSWORD", "root123"),
                database=os.getenv("DB_NAME", "testdb"),
                connection_timeout=5
            )

            if connection.is_connected():
                print("✅ Conectado a MySQL")

                cursor = connection.cursor()
                cursor.execute("SELECT * FROM users;")
                rows = cursor.fetchall()

                print("📊 Datos en la tabla:")
                for row in rows:
                    print(row)

                cursor.close()
                connection.close()
                break

        except mysql.connector.Error as e:
            print(f"⏳ Esperando MySQL... {e}")
            time.sleep(3)

        finally:
            if connection and connection.is_connected():
                connection.close()


if __name__ == "__main__":
    connect()
