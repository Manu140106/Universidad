CREATE DATABASE IF NOT EXISTS testdb;

USE testdb;


CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50)
);

INSERT INTO users (name)
SELECT * FROM (
                  SELECT 'Mario' AS name UNION
                  SELECT 'Ana' UNION
                  SELECT 'Carlos'
              ) AS tmp
WHERE NOT EXISTS (SELECT * FROM users);